package RepositorieSelectionner;

import Models.Selectionner;

import java.util.List;

public interface SelectionnerRepositorie {
    void saveSelectionner(Selectionner... selectionners);

    List<Selectionner> getSelectionner();

    void updateSelect(Selectionner... selectionners);

    Selectionner getSelectById(String idSelect, String idhoraire);

    Selectionner getSelectById(String idSelect);
}


