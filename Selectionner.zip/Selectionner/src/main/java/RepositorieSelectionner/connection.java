package RepositorieSelectionner;

import java.sql.Connection;
import java.sql.DriverManager;

public class connection {
    public static void main(String[] args) {
        try {
            String url = "jdbc:mysql://localhost:3306/ict-207";
            String user = "root";
            String passwd = "";

            // connexion à la BD
            Connection conn = DriverManager.getConnection(url, user, passwd);
            System.out.println("Connexion effective !");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
