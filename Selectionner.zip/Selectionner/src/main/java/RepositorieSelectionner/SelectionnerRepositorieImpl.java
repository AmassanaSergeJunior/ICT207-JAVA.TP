package RepositorieSelectionner;

import Database.SelectContract;
import Models.Selectionner;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SelectionnerRepositorieImpl implements SelectionnerRepositorie{

    private Connection connection ;
    public void SelectionnerRepositorieImpl (Connection connection)
    {
        this.connection= connection;
    }

    @Override
    public void saveSelectionner(Selectionner... selectionners)
    {
        for (Selectionner select : selectionners)
        {
            saveSelectionner(select);
        }

    }

    @Override
    public List<Selectionner> getSelectionner()
    {
        ArrayList<Selectionner> selectionners= new ArrayList<>();

        try{
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT *FROM"+ SelectContract.TABLE_NAME);
            while(resultSet.next())
            {
                Selectionner selectionner = extractSelectionner(resultSet);
                if (selectionner!= null)
                {
                    selectionners.add(selectionner);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return selectionners;
    }


    @Override
    public void updateSelect(Selectionner... selectionners) {

    }

    @Override
    public Selectionner getSelectById(String idSelect, String idhoraire) {
        return null;
    }


    @Override
    public Selectionner getSelectById(String idSelect) {
        return null;
    }

    public void saveOneSelect (Selectionner selectionner)
    {
        try{
            PreparedStatement statement = connection.prepareStatement("INSERT INTO " + SelectContract.TABLE_NAME + " ( " + SelectContract.ID_ENSEIGNANT_FIELD_NAME + " ) VALUES (?, ? )");
            statement.setString(1,selectionner.getId_enseignant());
            statement.setString(2,selectionner.getId_horaire());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Selectionner extractSelectionner(ResultSet resultSet) {
        try {
            String idEnse = resultSet.getString(SelectContract.ID_ENSEIGNANT_FIELD_NAME);
            String idhoraire = resultSet.getString(SelectContract.ID_HORAIRE_FIELD_NAME);
            return new Selectionner(idEnse, idhoraire);
        } catch (SQLException e) {
            return null;
        }
    }


}
