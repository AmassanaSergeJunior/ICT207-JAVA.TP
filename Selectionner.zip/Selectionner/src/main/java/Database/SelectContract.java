package Database;

public class SelectContract {
    public  static String TABLE_NAME = "Selectionner";
    public  static String ID_HORAIRE_FIELD_NAME = "id_horaire";
    public  static String ID_ENSEIGNANT_FIELD_NAME = "id_enseignant";

}
