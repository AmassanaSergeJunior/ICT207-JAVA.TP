module com.example.demo355 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.demo355 to javafx.fxml;
    exports com.example.demo355;
}