package Models;

public class Selectionner
{
        private int id_horaire;
        private int id_enseignant ;

    public Selectionner(String id_enseignant, String id_horaire)
    {
        this.id_horaire= id_horaire;
        this.id_enseignant= id_enseignant;
    }

    public void setId_horaire(int id_horaire) {
        this.id_horaire = id_horaire;
    }

    public String getId_horaire() {
        return id_horaire;
    }

    public String getId_enseignant() {
        return id_enseignant;
    }

    public void setId_enseignant(int id_enseigant) {
        this.id_enseignant = id_enseigant;
    }

}
